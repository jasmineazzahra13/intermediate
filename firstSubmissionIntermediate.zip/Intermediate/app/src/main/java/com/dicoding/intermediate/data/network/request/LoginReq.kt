package com.dicoding.intermediate.data.network.request

data class LoginReq (
    val email: String,
    val password: String
)