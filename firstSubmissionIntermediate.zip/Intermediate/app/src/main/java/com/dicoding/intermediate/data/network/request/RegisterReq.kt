package com.dicoding.intermediate.data.network.request

data class RegisterReq (
    val name: String,
    val email: String,
    val password: String
)