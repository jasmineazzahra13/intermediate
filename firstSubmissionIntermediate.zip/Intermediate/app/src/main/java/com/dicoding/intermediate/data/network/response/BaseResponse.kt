package com.dicoding.intermediate.data.network.response

data class BaseResponse (
    val error: Boolean,
    val message: String
)